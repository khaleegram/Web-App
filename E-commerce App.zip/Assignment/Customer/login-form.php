<?php
session_start(); // Start or resume the session

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Sanitize user inputs (consider using real escape functions or prepared statements)
    $username = htmlspecialchars($username);
    $password = htmlspecialchars($password);

    $servername = "localhost";
    $dbusername = "root";
    $dbpassword = "khaleefah12";
    $dbname = "webapp";

    $conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "SELECT customer_id FROM customers WHERE username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();

    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();

        // Remove checking the password for now

        // Successful login, store customer ID in the session
        $_SESSION['customer_id'] = $row['customer_id'];

        // Redirect to the next page
        header("Location: ..\Dashboard copy 2\index.php");
        exit();
    } else {
        echo "User not found";
    }

    $stmt->close();
    $conn->close();
}
?>
