<?php
class ProductModel {
    public function getProducts() {
        $conn = new mysqli("localhost", "root", "khaleefah12", "webapp");

        if ($conn->connect_error) {
            // Log connection error
            error_log("Connection failed: " . $conn->connect_error);
            die("Connection failed: " . $conn->connect_error);
        }

        $sql = "SELECT product_id, product_name, description, price, category_id, image_path, quantity FROM company_products";
        $result = $conn->query($sql);
        $products = [];

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $products[] = $row;
            }
        }

        $conn->close();
        return $products;
    }
}
?>

