<?php
require_once 'ProductModel.php';
require_once 'ProductView.php';

class ProductController {
    private $model;
    private $view;

    public function __construct() {
        $this->model = new ProductModel();
        $this->view = new ProductView();
    }

    public function displayProducts() {
        $products = $this->model->getProducts();
        $this->view->render($products);
    }
}
?>
