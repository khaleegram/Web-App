<?php
// product_card.php
echo "<div class='product-card' data-category='{$product["category_id"]}'>";
$imagePath = $product["image_path"];
echo "<img src='{$imagePath}' alt='Product Image' style='max-width: 100%;'><br>";
echo "<h3> " . $product["product_name"] . "</h3>";
echo "<p>Quantity: " . $product["quantity"] . "<br>";
echo "Price: $" . $product["price"] . "<br>";

// Form to add product to the cart
echo "<form action='view-cart.php' method='POST'>";
echo "<input type='hidden' name='product_id' value='{$product["product_id"]}'>";
echo "<input type='hidden' name='product_name' value='{$product["product_name"]}'>";
echo "<input type='hidden' name='price' value='{$product["price"]}'>";
echo "<input type='hidden' name='image_path' value='{$product["image_path"]}'>"; // Add this line
echo "<button type='submit' class='add-to-cart-btn' name='add_to_cart'>Add to Cart</button>";
echo "</form>";

echo "</div>";
?>
