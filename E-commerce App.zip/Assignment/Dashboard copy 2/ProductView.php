<?php
class ProductView {
    public function render($products) {
        include 'header.php';
        echo '<body>';

        echo "<div class='product-container'>";
        foreach ($products as $product) {
            include 'product_card.php';
        }
        echo "</div>";

        echo '</body></html>';
    }
}
?>
