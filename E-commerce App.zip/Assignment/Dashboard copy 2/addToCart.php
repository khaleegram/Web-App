<?php
// addToCart.php - This file handles adding items to the cart on the server side

// Assuming you have CartController instantiated
include('Controllers/CartController.php');

// Get data from the request
$data = json_decode(file_get_contents('php://input'), true);

// Example usage:
$cartModel = new CartModel();
$cartController = new CartController($cartModel);

// Add the item to the cart
$productId = $data['productId'];
$productName = $data['productName'];
$price = $data['price'];

$cartController->addToCart($productId, $productName, $price);

// Respond with a success message or updated cart data if needed
echo json_encode(['success' => true]);
?>
