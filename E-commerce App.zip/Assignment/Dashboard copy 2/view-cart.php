<?php
session_start();

// Handle the form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_to_cart'])) {
        $product_id = $_POST['product_id'];
        $product_name = $_POST['product_name'];
        $price = isset($_POST['price']) ? floatval($_POST['price']) : 0; // Ensure the price is numeric
        $quantity = 1;
        $image_path = $_POST['image_path']; // Get the image path

        // Initialize cart if not already set
        if (!isset($_SESSION['cart'])) {
            $_SESSION['cart'] = [];
        }

        // Add the product to the cart
        if (isset($_SESSION['cart'][$product_id])) {
            // Increment quantity if the product is already in the cart
            $_SESSION['cart'][$product_id]['quantity'] += 1;
        } else {
            // Add a new product to the cart
            $_SESSION['cart'][$product_id] = [
                'product_name' => $product_name,
                'price' => $price,
                'quantity' => $quantity,
                'image_path' => $image_path, // Store the image path in the cart
            ];
        }
    } elseif (isset($_POST['update_quantity'])) {
        $product_id = $_POST['product_id'];
        $quantity = isset($_POST['quantity']) ? intval($_POST['quantity']) : 1;

        // Update the quantity in the cart
        if (isset($_SESSION['cart'][$product_id])) {
            $_SESSION['cart'][$product_id]['quantity'] = $quantity;
        }
    } elseif (isset($_POST['delete_cart'])) {
        // Clear the entire cart
        $_SESSION['cart'] = [];
    }
}

// Display cart contents
$total_price = 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Cart</title>
    <link rel="stylesheet" href="cart.css">
</head>
<body>
<div class="container">
    <div class= "nav">
        <h1>Khaleegram E-Commerce</h1>
        <h2>Cart Summary</h2>
    </div>
        <?php if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])) : ?>
            <div class="cart-container">
                <?php foreach ($_SESSION['cart'] as $product_id => $product) : ?>
                    <div class="cart-item">
                        <img src='<?php echo $product['image_path']; ?>' alt='Product Image' class='product-image'>
                        <div class="product-details">
                            <h3><?php echo $product['product_name']; ?></h3>
                            <p>Price: $<?php echo is_numeric($product['price']) ? number_format($product['price'], 2) : $product['price']; ?></p>
                            <form action="view-cart.php" method="POST">
                                <label for="quantity">Quantity:</label>
                                <input type="number" name="quantity" id="quantity" value="<?php echo $product['quantity']; ?>" min="1">
                                <input type="hidden" name="product_id" value="<?php echo $product_id; ?>">
                                <input type="submit" name="update_quantity" id="update_quantity" value="Update Quantity">
                            </form>
                            <p>Total: $<?php echo is_numeric($product['price']) ? number_format($product['price'] * $product['quantity'], 2) : 0; ?></p>
                        </div>
                    </div>
                    <?php $total_price += is_numeric($product['price']) ? $product['price'] * $product['quantity'] : 0; ?>
                <?php endforeach; ?>
                <div class="total">
                    <p>Total Price: $<?php echo number_format($total_price, 2); ?></p>
                </div>
                <form action="view-cart.php" method="POST">
                    <input type="submit" name="delete_cart" value="Delete Cart">
                </form>
            </div>
        <?php else : ?>
            <p>Your cart is empty.</p>
        <?php endif; ?>
    </div>
</body>
</html>
