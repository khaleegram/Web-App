<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="top_nav.css">
    <script>
function addToCart(productId, productName, price) {
    // Display an alert for demonstration purposes
    alert(`Added to cart: ${productName} - $${price}`);
    
    // Additional logic to send the data to the server using AJAX
    var xhr = new XMLHttpRequest();
    xhr.open("POST", "add-to-cart.php", true);
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && xhr.status == 200) {
            // Handle the server's response if needed
            console.log(xhr.responseText);
        }
    };
    var data = "product_id=" + encodeURIComponent(productId) +
               "&product_name=" + encodeURIComponent(productName) +
               "&price=" + encodeURIComponent(price);
    xhr.send(data);

    // Reset the form if needed
    document.getElementById('cartForm').reset();
}
</script>
</head>
<body>
    <div class="topnav">
        <h1>Khaleegram E-Commerce</h1>
        <div class="nav">
            <a href="..\Seller\login-form.html">Seller</a>
            <a href="../../Assignment/Administrator/login-form.html">Admin</a>
            <a href="#order">Order</a>
            <a href="#about">About</a>
            <div class="Category">
                <a href="#about">Company Products</a>
                <a href="#about">Individual Products</a>
                <!-- Add a dropdown for categories -->
               
            </div>
        </div>
    </div>


        <div class="CompanyProduct" id="companyProducts">
            <select id="categoryFilter" onchange="filterProducts()">
                    <option value="0">All Categories</option>
                    <option value="1">Mobile Phones</option>
                    <option value="2">Electronics</option>
                    <option value="3">Clothing</option>
                    <!-- Add more categories as needed -->
                </select>
                <div class ="cart">
                <a href="view-cart.php">
                <button>
                    <img src="icons\shopping-cart.png" alt="" width="15" height="15">
                    <span>View Cart!</span>
                </button>
                </a>
                </div>

    </div>

    <script src="filter.js"></script>
</body>
</html>
