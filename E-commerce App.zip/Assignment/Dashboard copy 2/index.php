<?php
require_once 'ProductController.php';

$productController = new ProductController();
$productController->displayProducts();
?>
