<?php
session_start();

// Check if the form is submitted and the necessary parameters are set
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['product_id']) && isset($_POST['product_name']) && isset($_POST['price'])) {
    $product_id = $_POST['product_id'];
    $product_name = $_POST['product_name'];
    $price = (float)$_POST['price'];

    // Set the default quantity to 1
    $quantity = 1;

    // Initialize the cart if not already set
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }

    // Check if the product is already in the cart
    if (isset($_SESSION['cart'][$product_id])) {
        // Increment the quantity if the product is already in the cart
        $_SESSION['cart'][$product_id]['quantity'] += 1;
    } else {
        // Add the new product to the cart
        $_SESSION['cart'][$product_id] = [
            'product_name' => $product_name,
            'price' => $price,
            'quantity' => $quantity,
        ];
    }

    // Redirect to the view-cart.php after adding to the cart
    header("Location: view-cart.php");
    exit(); // Make sure to exit after the header to prevent further execution
} else {
    // Handle invalid or missing parameters
    echo "Invalid request. Missing parameters.";
}
?>
