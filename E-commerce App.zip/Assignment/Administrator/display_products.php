<?php
// Set the path to your error log file
$errorLogDirectory = 'Assignment/Dashboard/';
$errorLogFileName = 'error.log';
$errorLogFile = $errorLogDirectory . $errorLogFileName;

// Create the error log directory if it doesn't exist
if (!is_dir($errorLogDirectory)) {
    mkdir($errorLogDirectory, 0755, true);
}

// Open or create the error log file in append mode
if ($errorLogHandle = fopen($errorLogFile, 'a')) {
    $conn = new mysqli("localhost", "root", "khaleefah12", "webapp");

    if ($conn->connect_error) {
        // Log connection error to the file
        error_log("Connection failed: " . $conn->connect_error, 3, $errorLogFile);
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "SELECT product_id, product_name, description, price, category_id, image_path, quantity FROM company_products";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            // Include the JavaScript code to create product cards
            echo "<script>";
            echo "createProductCard(" . json_encode($row) . ");";
            echo "</script>";
        }
    } else {
        echo "0 results";
    }

    // Close the database connection
    $conn->close();

    // Close the error log file handle
    fclose($errorLogHandle);
} else {
    die("Error opening the error log file.");
}
?>
<script>
    function createProductCard(productData) {
        // Clone the product card template
        var productCard = document.querySelector('.product-card').cloneNode(true);

        // Set product data in the card
        productCard.querySelector('.product-name').textContent = 'Product Name: ' + productData.product_name;
        productCard.querySelector('.product-description').textContent = 'Description: ' + productData.description;
        productCard.querySelector('.product-price').textContent = 'Price: $' + productData.price;
        productCard.querySelector('.product-quantity').textContent = 'Quantity: ' + productData.quantity;
        productCard.querySelector('.product-image').src = productData.image_path;
        productCard.querySelector('.complete-url').textContent = 'Complete URL: ' + productData.image_path;

        // Append the product card to the body or any container element
        document.body.appendChild(productCard);
    }
</script>
