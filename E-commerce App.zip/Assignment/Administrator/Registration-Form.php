<?php
$servername = "localhost";
$dbusername = "root";
$dbpassword = "khaleefah12";
$dbname = "webapp";

try {
    $conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);

    if ($conn->connect_error) {
        throw new Exception("Connection failed: " . $conn->connect_error);
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $firstName = $_POST['first-name'];
        $lastName = $_POST['last-name'];
        $username = $_POST['username'];
        $email = $_POST['email'];
        $address = $_POST['address'];
        $password = password_hash($_POST["password"], PASSWORD_DEFAULT);
        $confirmPassword = $_POST['confirm-password'];
        $ccode = $_POST['code']; // Assuming 'code' is the field for the company code

        // Check if provided 'ccode' exists in the database
        $checkCodeQuery = "SELECT * FROM company_codes WHERE code_value = ? AND is_used = FALSE";
        $checkCodeStmt = $conn->prepare($checkCodeQuery);
        $checkCodeStmt->bind_param("s", $ccode);
        $checkCodeStmt->execute();
        $codeResult = $checkCodeStmt->get_result();

        if ($codeResult->num_rows === 0) {
            echo "<script>alert('Invalid verification code.'); window.location.href = 'Registration-Form.html';</script>";
            exit();
        } else {
            // Mark the code as used
            $updateCodeQuery = "UPDATE company_codes SET is_used = TRUE WHERE code_value = ?";
            $updateCodeStmt = $conn->prepare($updateCodeQuery);
            $updateCodeStmt->bind_param("s", $ccode);
            $updateCodeStmt->execute();
            $updateCodeStmt->close();

            echo "<script>alert('Verification code found!');</script>";
        }

        // Check if the username already exists
        $checkUsernameQuery = "SELECT * FROM administrators WHERE username = ?";
        $checkStmt = $conn->prepare($checkUsernameQuery);
        $checkStmt->bind_param("s", $username);
        $checkStmt->execute();
        $result = $checkStmt->get_result();

        if ($result->num_rows > 0) {
            echo "<script>alert('Username already in use. Please choose a different username.'); window.location.href = 'SignUp.html';</script>";
            exit();
        }

        // Insert user data into the 'administrators' table
        $insertQuery = "INSERT INTO administrators (first_name, last_name, username, email, address, password) VALUES (?, ?, ?, ?, ?, ?)";
        $insertStmt = $conn->prepare($insertQuery);
        $insertStmt->bind_param("ssssss", $firstName, $lastName, $username, $email, $address, $password);

        if ($insertStmt->execute()) {
            echo "<script>alert('Registration successful!'); window.location.href = 'login-form.html';</script>";
            exit();
        } else {
            throw new Exception("Error: " . $insertStmt->error);
        }

        $insertStmt->close();
    }
} catch (Exception $e) {
    echo "<script>alert('" . $e->getMessage() . "'); window.location.href = 'Registration-Form.html';</script>";
}

$conn->close();
?>
