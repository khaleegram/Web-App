<?php
$servername = "localhost";
$username = "root";
$password = "khaleefah12";

// Create connection
$conn = new mysqli($servername, $username, $password);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $firstName = $_POST['first-name'];
    $lastName = $_POST['last-name'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $address = $_POST['address'];
    $password = password_hash($_POST["password"], PASSWORD_DEFAULT);
    $confirmPassword = $_POST['confirm-password'];
    $ccode = $_POST['ccode'];

    // Check if provided 'ccode' exists in the database
    $checkCodeQuery = "SELECT * FROM verification_codes WHERE code = ?";
    $checkCodeStmt = $conn->prepare($checkCodeQuery);
    $checkCodeStmt->bind_param("s", $ccode);
    $checkCodeStmt->execute();
    $codeResult = $checkCodeStmt->get_result();

    if ($codeResult->num_rows === 0) {
        throw new Exception("Invalid verification code.");
    }

    // Check if the username already exists
    $checkUsernameQuery = "SELECT * FROM administrator_info WHERE username = ?";
    $checkStmt = $conn->prepare($checkUsernameQuery);
    $checkStmt->bind_param("s", $username);
    $checkStmt->execute();
    $result = $checkStmt->get_result();

    if ($result->num_rows > 0) {
        throw new Exception("Username already in use. Please choose a different username.");
    }

    // Insert user data into the 'users' table
    $insertQuery = "INSERT INTO users (username, firstName, lastName, email, password) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($insertQuery);
    $stmt->bind_param("sssss", $username, $firstName, $lastName, $email, $password);

    if ($stmt->execute()) {
        echo "<script>alert('Registration successful!'); window.location.href = 'signIn.html';</script>";
        exit();
    } else {
        throw new Exception("Error: " . $stmt->error);
    }

    $stmt->close();
}


$conn->close();
?>
