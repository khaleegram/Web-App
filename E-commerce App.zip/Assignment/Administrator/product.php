<?php
$servername = "localhost";
$dbusername = "root";
$dbpassword = "khaleefah12";
$dbname = "webapp";

try {
    $conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);

    // Check connection
    if ($conn->connect_error) {
        throw new Exception("Connection failed: " . $conn->connect_error);
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Validate and sanitize form input
        $productName = htmlspecialchars($_POST['productName']);
        $description = htmlspecialchars($_POST['description']);
        $price = floatval($_POST['price']);
        $quantity = intval($_POST['quantity']);
        $category = intval($_POST['category']);

        // Handle file upload for one image only
        $targetDirectory = "uploads/";
        $targetFile = $targetDirectory . basename($_FILES['product_image']['name']);

        // Validate and move uploaded file
        if (move_uploaded_file($_FILES['product_image']['tmp_name'], $targetFile)) {
            // Insert product data into the company_products table
            $insertProductQuery = "INSERT INTO company_products (product_name, description, price, quantity, category_id, image_path) VALUES (?, ?, ?, ?, ?, ?)";
            $stmtProduct = $conn->prepare($insertProductQuery);

            // Check if the statement is prepared successfully
            if (!$stmtProduct) {
                throw new Exception("Error preparing statement: " . $conn->error);
            }

            // Bind parameters
            $stmtProduct->bind_param("ssdiss", $productName, $description, $price, $quantity, $category, $imagePath);

            // Set the image path variable
            $imagePath = $targetFile;

            // Execute the statement
            if ($stmtProduct->execute()) {
                echo "<script>alert('Product added successfully!');</script>";
                echo "<script>window.location.href = 'confirmation.php';</script>";

            } else {
                throw new Exception("Error executing statement: " . $stmtProduct->error);
            }

            // Close the statement
            $stmtProduct->close();
        } else {
            throw new Exception("Error uploading image.");
        }
    }
} catch (Exception $e) {
    // Log the error to a file or a log system
    error_log($e->getMessage(), 3, "error.log");

    // Display a user-friendly error message
    echo "<script>alert('An error occurred. Please try again later.');</script>";
}

// Close the database connection
$conn->close();
?>
