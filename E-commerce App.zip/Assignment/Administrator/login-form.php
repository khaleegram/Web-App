<?php
$servername = "localhost";
$dbusername = "root";
$dbpassword = "khaleefah12";
$dbname = "webapp";

try {
    $conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);

    if ($conn->connect_error) {
        throw new Exception("Connection failed: " . $conn->connect_error);
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $username = $_POST['username'];
        $password = $_POST["password"];

        // Check if the provided username exists
        $checkUsernameQuery = "SELECT * FROM administrators WHERE username = ?";
        $checkStmt = $conn->prepare($checkUsernameQuery);
        $checkStmt->bind_param("s", $username);
        $checkStmt->execute();
        $result = $checkStmt->get_result();

        if ($result->num_rows === 0) {
            echo "<script>alert('Invalid username.'); window.location.href = 'login-form.html';</script>";
            exit();
        }

        // Verify the password
        $row = $result->fetch_assoc();
        if (password_verify($password, $row['password'])) {
            echo "<script>alert('Login successful!'); window.location.href = 'admin.html';</script>";
            exit();
        } else {
            echo "<script>alert('Invalid password.'); window.location.href = 'login-form.html';</script>";
            exit();
        }
    }
} catch (Exception $e) {
    echo "<script>alert('" . $e->getMessage() . "'); window.location.href = 'login-form.html';</script>";
}

$conn->close();
?>
