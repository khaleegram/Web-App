<?php

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $servername = "localhost";
    $dbusername = "root";
    $dbpassword = "khaleefah12";
    $dbname = "assignment";

    $conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Use prepared statement to prevent SQL injection
    $sql = "SELECT * FROM users WHERE username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $storedPassword = $row['password'];

    
        echo "<script>alert('Incorrect Password.'); window.location.href = 'SignIn.html';</script>";



        // Verify password using password_verify
        if (password_verify($password, $storedPassword)) {
            echo "Password verified successfully. Redirecting to dashboard...";
             header("Location: dashboard.html");
            exit();
        } else {
            echo "Incorrect password";
        }
    } else {
        echo "User not found";
    }

    // Close prepared statement and database connection
    $stmt->close();
    $conn->close();
}

?>
