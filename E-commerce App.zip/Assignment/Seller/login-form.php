<?php
$servername = "localhost";
$dbusername = "root";
$dbpassword = "khaleefah12";
$dbname = "webapp";

try {
    $conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);

    // Check connection
    if ($conn->connect_error) {
        throw new Exception("Connection failed: " . $conn->connect_error);
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $username = htmlspecialchars($_POST['username']);
        $password = $_POST['password'];

        // Validate username
        if (!preg_match("/^[a-zA-Z0-9_]{3,15}$/", $username)) {
            echo "<script>alert('Invalid username.');</script>";
            exit();
        }

        // Check if the username exists
        $checkUsernameQuery = "SELECT * FROM sellers WHERE username = ?";
        $checkStmt = $conn->prepare($checkUsernameQuery);
        $checkStmt->bind_param("s", $username);
        $checkStmt->execute();
        $result = $checkStmt->get_result();

        if ($result->num_rows == 0) {
            echo "<script>alert('Invalid username.'); window.location.href = 'login-form.html';</script>";
            exit();
        }

        // Verify password
        $userRow = $result->fetch_assoc();

        // Include the seller ID in the session for later use
        session_start();
        $_SESSION['seller_id'] = $userRow['seller_id'];

        if (password_verify($password, $userRow['password'])) {
            // Redirect to a dashboard or home page
            header("Location: seller.html");
            exit();
        } else {
            echo "<script>alert('Invalid password.'); window.location.href = 'login-form.html';</script>";
            exit();
        }

        $checkStmt->close();
    }
} catch (Exception $e) {
    // Log the error to a file or a log system
    error_log($e->getMessage(), 3, "error.log");

    // Display a user-friendly error message
    echo "<script>alert('An error occurred. Please try again later.'); window.location.href = 'login-form.html';</script>";
}

// Close the database connection
$conn->close();
?>
