<?php
$servername = "localhost";
$dbusername = "root";
$dbpassword = "khaleefah12";
$dbname = "webapp";

try {
    $conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);

    // Check connection
    if ($conn->connect_error) {
        throw new Exception("Connection failed: " . $conn->connect_error);
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Assuming your form fields are named productName, description, price, category_id, and quantity

        // Obtain the seller ID from the session
        session_start();
        $seller_id = $_SESSION['seller_id'];

        $productName = $_POST['productName'];
        $description = $_POST['description'];
        $price = $_POST['price'];
        $category_id = $_POST['category_id'];
        $quantity = $_POST['quantity'];

        // Loop through each uploaded file
        foreach ($_FILES["product_images"]["name"] as $key => $fileName) {
            $targetFile = $targetDir . basename($fileName);

            // Check if file already exists
            if (file_exists($targetFile)) {
                echo "Sorry, file already exists.";
                $uploadOk = 0;
                exit();
            }

            // Move the uploaded file to the target directory
            if (move_uploaded_file($_FILES["product_images"]["tmp_name"][$key], $targetFile)) {
                $targetFiles[] = $targetFile;
            } else {
                echo "Sorry, there was an error uploading your file.";
                exit();
            }
        }

        // Insert product data into the individual_products table for each uploaded image
        $insertProductQuery = "INSERT INTO individual_products (product_name, description, price, quantity, seller_id, category_id, image_path) VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmtProduct = $conn->prepare($insertProductQuery);

        // Check if the statement is prepared successfully
        if (!$stmtProduct) {
            throw new Exception("Error preparing statement: " . $conn->error);
        }

        // Loop through target files and insert data
        foreach ($targetFiles as $targetFile) {
            // Bind parameters
            $stmtProduct->bind_param("ssdiiss", $productName, $description, $price, $quantity, $seller_id, $category_id, $targetFile);

            // Execute the statement
            if ($stmtProduct->execute()) {
                echo "Product added successfully!";
            } else {
                throw new Exception("Error executing statement: " . $stmtProduct->error);
            }
        }

        // Close the statement
        $stmtProduct->close();
    }
} catch (Exception $e) {
    // Log the error to a file or a log system
    error_log($e->getMessage(), 3, "error.log");

    // Display a user-friendly error message
    echo "An error occurred. Please try again later.";
}

// Close the database connection
$conn->close();
?>
