
    function searchByCategory(type) {
        var searchInput = (type === 'company') ? document.getElementById('companySearchInput').value : document.getElementById('individualSearchInput').value;

        // Perform AJAX request to search.php
        var xhr = new XMLHttpRequest();
        xhr.open('POST', 'search.php', true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        
        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4 && xhr.status === 200) {
                // Parse the JSON response
                var products = JSON.parse(xhr.responseText);

                // Display products on the main page
                displayProducts(products, type);
            }
        };

        // Send the request with the search input
        xhr.send(type + 'SearchButton=true&' + type + 'SearchInput=' + searchInput);
    }

    function displayProducts(products, type) {
        var productContainer = document.getElementById(type + 'Products');

        // Clear previous products
        productContainer.innerHTML = '';

        // Loop through products and create product cards
        for (var i = 0; i < products.length; i++) {
            var product = products[i];

            // Create a product card element
            var productCard = document.createElement('div');
            productCard.className = 'product-card';
            
            // Set the background image of the card
            productCard.style.backgroundImage = 'url(' + product.image + ')';

            // Create elements for name, price, etc.
            var productName = document.createElement('h3');
            productName.innerText = product.product_name;

            var productDescription = document.createElement('p');
            productDescription.innerText = product.description;

            var productPrice = document.createElement('p');
            productPrice.innerText = 'Price: $' + product.price;

            // Make the card clickable (you can add an onclick function)
            productCard.onclick = function () {
                // Handle the click event, e.g., redirect to the product page
                alert('Product Clicked: ' + product.product_name);
            };

            // Append elements to the card
            productCard.appendChild(productName);
            productCard.appendChild(productDescription);
            productCard.appendChild(productPrice);

            // Append the card to the product container
            productContainer.appendChild(productCard);
        }
    }

    document.addEventListener('DOMContentLoaded', function () {
        // Add a click event listener to category containers
        document.querySelectorAll('.category-container').forEach(function (container) {
            container.addEventListener('click', function () {
                // Get the selected category
                var category = container.getAttribute('data-category');
    
                // Perform AJAX request to load products for the selected category
                loadProducts(category);
            });
        });
    });
    
    function loadProducts(category) {
        // Perform AJAX request to fetch products for the selected category
        var xhr = new XMLHttpRequest();
        xhr.open('POST', 'load_products.php', true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    
        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4 && xhr.status === 200) {
                // Parse the JSON response
                var products = JSON.parse(xhr.responseText);
    
                // Display products on the main page
                displayProducts(products);
            }
        };
    
        // Send the request with the selected category
        xhr.send('category=' + category);
    }

