<?php
header('Content-Type: application/json');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $servername = "localhost";
    $username = "root";
    $password = "khaleefah12";
    $dbname = "webapp";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $selectedCategory = $_POST['category'];
    $query = "SELECT * FROM company_products WHERE category = '$selectedCategory'";

    $result = $conn->query($query);

    $products = [];

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $products[] = [
                'product_name' => $row['product_name'],
                'description' => $row['description'],
                'price' => $row['price'],
                'image' => $row['image_path'], // Assuming you have a column for the image path in the database
            ];
        }
    }

    $conn->close();

    echo json_encode($products);
}
?>
