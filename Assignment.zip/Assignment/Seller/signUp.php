<?php
$servername = "localhost";
$dbusername = "root";
$dbpassword = "khaleefah12";
$dbname = "webapp";

try {
    $conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);

    // Check connection
    if ($conn->connect_error) {
        throw new Exception("Connection failed: " . $conn->connect_error);
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Validate and sanitize form input
        $fullName = htmlspecialchars($_POST['fullname']);
        $username = htmlspecialchars($_POST['username']);
        $email = htmlspecialchars($_POST['email']);
        $address = htmlspecialchars($_POST['address']);
        $businessType = htmlspecialchars($_POST['Businesstype']);
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

        // Validate username
        if (!preg_match("/^[a-zA-Z0-9_]{3,15}$/", $username)) {
            echo "<script>alert('Invalid username. Username must be 3-15 characters and can contain letters, numbers, and underscores.');</script>";
            exit();
        }

        // Check if the username already exists
        $checkUsernameQuery = "SELECT * FROM sellers WHERE username = ?";
        $checkStmt = $conn->prepare($checkUsernameQuery);
        $checkStmt->bind_param("s", $username);
        $checkStmt->execute();
        $result = $checkStmt->get_result();

        if ($result->num_rows > 0) {
            echo "<script>alert('Username already in use. Please choose a different username.');</script>";
            exit();
        }

        // Insert seller data into the sellers table
        $insertSellerQuery = "INSERT INTO sellers (fullname, username, email, address, password, business_type) VALUES (?, ?, ?, ?, ?, ?)";
        $stmtSeller = $conn->prepare($insertSellerQuery);

        // Check if the statement is prepared successfully
        if (!$stmtSeller) {
            throw new Exception("Error preparing statement: " . $conn->error);
        }

        // Bind parameters
        $stmtSeller->bind_param("ssssss", $fullName, $username, $email, $address, $password, $businessType);

        // Execute the statement
        if ($stmtSeller->execute()) {
            echo "<script>alert('Seller registered successfully!');</script>";
        } else {
            throw new Exception("Error executing statement: " . $stmtSeller->error);
        }

        // Close the statement
        $stmtSeller->close();
    }
} catch (Exception $e) {
    // Log the error to a file or a log system
    error_log($e->getMessage(), 3, "error.log");

    // Display a user-friendly error message
    echo "<script>alert('An error occurred. Please try again later.');</script>";
}

// Close the database connection
$conn->close();
?>
