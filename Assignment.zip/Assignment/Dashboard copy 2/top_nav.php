<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="top_nav.css">
</head>
<body>
    <div class="topnav">
        <h1>Khaleegram E-Commerce</h1>
        <div class="nav">
            <a href="#seller">Seller</a>
            <a href="#customer">Customer</a>
            <a href="#order">Order</a>
            <a href="#about">About</a>
            <div class="Category">
                <a href="#about">Company Products</a>
                <a href="#about">Individual Products</a>
                <!-- Add a dropdown for categories -->
               
            </div>
        </div>
    </div>

    <div class="product">
        <div class="CompanyProduct" id="companyProducts">
            <h2>Product From Our Organization</h2>
            <select id="categoryFilter" onchange="filterProducts()">
                    <option value="0">All Categories</option>
                    <option value="1">Mobile Phones</option>
                    <option value="2">Electronics</option>
                    <option value="3">Clothing</option>
                    <!-- Add more categories as needed -->
                </select>
        </div>
    </div>

    <script src="filter.js"></script>
</body>
</html>
