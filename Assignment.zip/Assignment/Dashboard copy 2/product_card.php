<!-- Loop through your products and generate product cards -->
<?php foreach ($products as $product): ?>
    <div class="product-card">
        <img src="<?php echo $product['image_path']; ?>" alt="Product Image" style="max-width: 200px;">
        <h3><?php echo $product['product_name']; ?></h3>
        <p>Quantity: <?php echo $product['quantity']; ?><br>
        Price: $<?php echo $product['price']; ?><br>
        Category ID: <?php echo $product['category_id']; ?></p>
        <button class="add-to-cart-btn" 
                data-product-id="<?php echo $product['product_id']; ?>"
                data-product-name="<?php echo $product['product_name']; ?>"
                data-product-price="<?php echo $product['price']; ?>">Add to Cart</button>
    </div>
<?php endforeach; ?>
