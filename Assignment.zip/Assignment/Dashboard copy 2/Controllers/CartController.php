public function addToCart() {
    $productId = isset($_POST['productId']) ? $_POST['productId'] : '';
    $productName = isset($_POST['productName']) ? $_POST['productName'] : '';
    $productPrice = isset($_POST['productPrice']) ? $_POST['productPrice'] : '';

    // You can now use $productId, $productName, and $productPrice to add the product to the cart
    // Call methods in CartModel to add items to the cart and return any relevant data

    // For example, assuming addToCart method in CartModel returns the added item:
    $addedItem = $this->cartModel->addToCart($productName, $productPrice);
    
    // Return the added item as JSON
    echo json_encode($addedItem);
}
