// filter.js

function filterProducts() {
    // Get the selected category value
    var selectedCategory = document.getElementById("categoryFilter").value;

    // Get all product cards
    var productCards = document.getElementsByClassName("product-card");

    // Loop through each product card
    for (var i = 0; i < productCards.length; i++) {
        // Get the category ID of the product card
        var cardCategory = productCards[i].getAttribute("data-category");

        // Check if the selected category is "All Categories" or matches the card's category
        if (selectedCategory === "0" || selectedCategory === cardCategory) {
            // Show the product card
            productCards[i].style.display = "block";
        } else {
            // Hide the product card
            productCards[i].style.display = "none";
        }
    }
}
