// JavaScript code for handling user interactions
document.addEventListener('DOMContentLoaded', function() {
    // Get all buttons with the class 'add-to-cart-btn'
    var addToCartButtons = document.querySelectorAll('.add-to-cart-btn');

    // Add click event listener to each button
    addToCartButtons.forEach(function(button) {
        button.addEventListener('click', function() {
            // Extract product information from the button's data attributes
            var productId = button.getAttribute('data-product-id');
            var productName = button.getAttribute('data-product-name');
            var productPrice = button.getAttribute('data-product-price');

            // Call the addToCart function to send the data to the server
            addToCart(productId, productName, productPrice);
        });
    });

    // Function to add the product to the cart
    function addToCart(productId, productName, productPrice) {
        // Use AJAX to send a request to the server-side PHP (CartController)
        // Update the cart display based on the response

        // Placeholder AJAX request (using jQuery)
        $.ajax({
            url: 'index.php?action=addToCart',
            method: 'POST',
            data: { productId: productId, productName: productName, productPrice: productPrice },
            success: function(response) {
                // Handle the response if needed
            }
        });
    }
});
