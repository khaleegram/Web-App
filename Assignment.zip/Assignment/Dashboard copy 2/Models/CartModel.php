<?php
class CartModel {
    private $cartItems = [];

    public function addToCart($productName, $price) {
        $item = [
            'productName' => $productName,
            'price' => $price
        ];

        $this->cartItems[] = $item;
        return $item;
    }

    public function getCartItems() {
        return $this->cartItems;
    }
}
?>
