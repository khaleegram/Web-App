<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart</title>
    <style>
        /* Add your CSS styles for the cart here */
        /* Example styles: */
        #cart {
            border: 1px solid #ddd;
            padding: 10px;
            margin-top: 20px;
            border-radius: 10px;
            background-color: #f8f8f8;
        }

        #cart h2 {
            margin-bottom: 10px;
        }

        #cart-items {
            list-style-type: none;
            padding: 0;
        }

        #cart-items li {
            margin-bottom: 5px;
        }

        #total {
            font-weight: bold;
        }
    </style>
</head>
<body>
    <!-- Display the shopping cart -->
<!-- HTML code for displaying the cart -->
<div id="cart">
    <h2>Shopping Cart</h2>
    <ul id="cart-items">
        <?php foreach ($cartItems as $item): ?>
            <li><?php echo $item['productName']; ?> - $<?php echo $item['price']; ?></li>
        <?php endforeach; ?>
    </ul>
    <p>Total: $<span id="total"><?php echo array_sum(array_column($cartItems, 'price')); ?></span></p>
</div>

<!-- JavaScript code for handling user interactions -->
<script src="js/cart.js"></script>

</body>
</html>
