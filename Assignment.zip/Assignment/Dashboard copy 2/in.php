<?php
// Entry point for your application
// Instantiate models, controllers, and include necessary files

// Example usage:
$cartModel = new CartModel();
$cartController = new CartController($cartModel);

// Check for actions in the URL
$action = isset($_GET['action']) ? $_GET['action'] : '';

switch ($action) {
    case 'addToCart':
        $productName = isset($_POST['productName']) ? $_POST['productName'] : '';
        $price = isset($_POST['price']) ? $_POST['price'] : '';
        $cartController->addToCart($productName, $price);
        break;
    default:
        $cartController->viewCart();
}
?>
