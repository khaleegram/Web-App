<?php
// Connect to the database (you should replace the connection details)
include 'config.php';


// Fetch categories from the database
$sql = "SELECT * FROM company_products";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Category Display</title>
</head>
<body>

    <h2>Categories:</h2>

    <?php
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo "<p>{$row['product_name']}</p>";
        }
    } else {
        echo "No categories found.";
    }

    // Close the database connection
    $conn->close();
    ?>

</body>
</html>
