<?php
$servername = "localhost";
$dbusername = "root";
$dbpassword = "khaleefah12";
$dbname = "webapp";

try {
    $conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);

    if ($conn->connect_error) {
        throw new Exception("Connection failed: " . $conn->connect_error);
    }else{
        echo "Connection succeeded: " ;
    }

    // Other database-related operations can go here

} catch (Exception $e) {
    // Handle the exception, log the error, or display an error message
    // For example, you can log the error to a file or send an email to the administrator
    error_log("Database Connection Error: " . $e->getMessage(), 3, "error.log");

    // Optionally, you can display a user-friendly error message
    echo "Sorry, we are experiencing technical difficulties. Please try again later.";
}

// The connection will be automatically closed when the script finishes execution
?>
