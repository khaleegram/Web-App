// productCard.js

function createProductCard(productData) {
    // Create product card container
    var productCard = document.createElement("div");
    productCard.className = "product-card";

    // Create and set image
    var productImage = document.createElement("img");
    productImage.src = productData.imagePath;
    productImage.alt = "Product Image";
    productImage.style.maxWidth = "500px";
    productImage.style.maxHeight = "500px";
    productCard.appendChild(productImage);

    // Create and set product name
    var productName = document.createElement("p");
    productName.textContent = "Name: " + productData.name;
    productCard.appendChild(productName);

    // Create and set price
    var productPrice = document.createElement("p");
    productPrice.textContent = "Price: $" + productData.price;
    productCard.appendChild(productPrice);

    // Create and set quantity
    var productQuantity = document.createElement("p");
    productQuantity.textContent = "Quantity: " + productData.quantity;
    productCard.appendChild(productQuantity);

    // Append product card to the body
    document.body.appendChild(productCard);
}
