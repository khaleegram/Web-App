<?php
    include 'config.php';

    
    $sql = "SELECT product_id, product_name, description, price, category_id, image_path, quantity FROM company_products";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            // Include the HTML template for product card
            include 'product_card_template.html';
    
            echo "<hr>"; // Optional: Add a horizontal line between products
        }
    } else {
        echo "0 results";
    }
    
    // Close the database connection
    $conn->close();
    ?>