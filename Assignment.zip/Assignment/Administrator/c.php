<?php
// Set the path to your error log file
$errorLogDirectory = 'Assignment/Dashboard/';
$errorLogFileName = 'error.log';
$errorLogFile = $errorLogDirectory . $errorLogFileName;

// Create the error log directory if it doesn't exist
if (!is_dir($errorLogDirectory)) {
    mkdir($errorLogDirectory, 0755, true);
}

// Open or create the error log file in append mode
if ($errorLogHandle = fopen($errorLogFile, 'a')) {
    $conn = new mysqli("localhost", "root", "khaleefah12", "webapp");

    if ($conn->connect_error) {
        // Log connection error to the file
        error_log("Connection failed: " . $conn->connect_error, 3, $errorLogFile);
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "SELECT product_id, product_name, description, price, category_id, image_path, quantity FROM company_products";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Include the CSS styles in the head of the HTML document
        echo '
        <!DOCTYPE html>
        <html lang="en">
        <head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Product Card</title>
          <style>
            /* Basic styling for the product card */
            .product-card {
              border: 1px solid #ddd;
              padding: 10px;
              margin: 10px;
              width: 200px;
            }

            /* Style for the "Add to Cart" button */
            .add-to-cart-btn {
              background-color: #4CAF50;
              color: white;
              padding: 10px;
              text-align: center;
              text-decoration: none;
              display: inline-block;
              border-radius: 5px;
              cursor: pointer;
            }
          </style>
        </head>
        <body>
        ';

        while ($row = $result->fetch_assoc()) {
            $imagePath = $row["image_path"];
            echo "<div class='product-card'>";
            echo "<img src='{$imagePath}' alt='Product Image' style='max-width: 200px;'><br>";
            echo "<h3>Product Name: " . $row["product_name"] . "</h3>";
            echo "<p>Quantity: " . $row["quantity"] . "<br>";
            echo "Price: $" . $row["price"] . "<br>";
            echo "Category ID: " . $row["category_id"] . "</p>";
            echo "<button class='add-to-cart-btn'>Add to Cart</button>";
            echo "</div>";
            echo "-------------------------<br>";
        }

        // Close the HTML body and document
        echo '</body></html>';
    } else {
        echo "0 results";
    }

    // Close the database connection
    $conn->close();

    // Close the error log file handle
    fclose($errorLogHandle);
} else {
    die("Error opening the error log file.");
}
?>
