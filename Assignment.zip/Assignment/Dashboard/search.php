<?php
header('Content-Type: application/json');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Establish a connection to your MySQL database
    $servername = "localhost";
    $username = "root";
    $password = "khaleefah12";
    $dbname = "webapp";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Check which form was submitted
    if (isset($_POST["companySearchButton"])) {
        $searchInput = $_POST["companySearchInput"];
        // Perform a database query for company products based on the category
        $sql = "SELECT * FROM company_products WHERE category LIKE '%$searchInput%'";
        $result = $conn->query($sql);
    } elseif (isset($_POST["individualSearchButton"])) {
        $searchInput = $_POST["individualSearchInput"];
        // Perform a database query for individual products based on the category
        $sql = "SELECT * FROM individual_products WHERE category LIKE '%$searchInput%'";
        $result = $conn->query($sql);
    }

    // Handle the search results as JSON
    $products = [];

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            // Add each product to the array
            $products[] = [
                'product_name' => $row['product_name'],
                'description' => $row['description'],
                'price' => $row['price'],
                'image' => $row['image_path'], // Assuming you have a column for the image path in the database
            ];
        }
    }

    // Close the database connection
    $conn->close();

    // Return the products as JSON
    echo json_encode($products);
}
?>
