<?php
$servername = "localhost";
$dbusername = "root";
$dbpassword = "khaleefah12";
$dbname = "webapp";

$conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$individualCategoriesQuery = "SELECT DISTINCT category_id FROM individual_product"; // Replace 'individual_table' with your actual individual table name
$individualCategoriesResult = $conn->query($individualCategoriesQuery);

$conn->close();

// Display categories or use them as needed in your HTML
while ($row = $individualCategoriesResult->fetch_assoc()) {
    echo "<div class='category-container' data-category='" . $row['category_id'] . "'>" . $row['category_id'] . "</div>";
}
?>
