<?php
$servername = "localhost";
$dbusername = "root";
$dbpassword = "khaleefah12";
$dbname = "webapp";

$conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$companyCategoriesQuery = "SELECT DISTINCT category_id FROM company_product"; // Replace 'company_table' with your actual company table name
$companyCategoriesResult = $conn->query($companyCategoriesQuery);

$conn->close();

// Display categories or use them as needed in your HTML
while ($row = $companyCategoriesResult->fetch_assoc()) {
    echo "<div class='category-container' data-category='" . $row['category_id'] . "'>" . $row['category_id'] . "</div>";
}
?>
