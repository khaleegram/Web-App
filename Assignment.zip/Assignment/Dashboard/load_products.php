<?php
header('Content-Type: application/json');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $servername = "localhost";
    $dbusername = "root";
    $dbpassword = "khaleefah12";
    $dbname = "webapp";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Determine the table based on the type (company or individual)
    $table = ($_POST['type'] == 'company') ? 'company_product' : 'individual_product';

    // Fetch all categories
    $categoriesQuery = "SELECT * FROM category";
    $categoriesResult = $conn->query($categoriesQuery);

    $productsByCategory = [];

    if ($categoriesResult->num_rows > 0) {
        while ($categoryRow = $categoriesResult->fetch_assoc()) {
            $selectedCategory = $categoryRow['category_name'];

            $query = "SELECT * FROM $table WHERE category_id = (SELECT id FROM category WHERE category_name = '$selectedCategory')";
            $result = $conn->query($query);

            $products = [];

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $products[] = [
                        'product_name' => $row['product_name'],
                        'description' => $row['description'],
                        'price' => $row['price'],
                        'image' => $row['image_path'],
                    ];
                }
            }

            $productsByCategory[$selectedCategory] = $products;
        }
    }

    $conn->close();

    echo json_encode($productsByCategory);
}
?>
